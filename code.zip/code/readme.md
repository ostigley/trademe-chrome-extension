This is a work in progress for a chrome extension to be used with www.trademe.co.nz.  It will enable append a 'view next' link to a listing page.  

The link will take them the to the next item in the listing, removing the need to click 'back' to the results, then to on to the next listing. 